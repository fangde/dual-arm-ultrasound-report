"""Fetch the public Menagerie Panda meshes referenced by the vendored XML."""
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
import urllib.request
import xml.etree.ElementTree as ET

root = Path(__file__).parent / 'assets'
dest = root / 'assets'
dest.mkdir(exist_ok=True)
files = sorted({m.attrib['file'] for m in ET.parse(root / 'panda.xml').findall('.//mesh') if 'file' in m.attrib})
def fetch(name):
    path = dest / name
    if not path.exists():
        urllib.request.urlretrieve('https://raw.githubusercontent.com/google-deepmind/mujoco_menagerie/main/franka_emika_panda/assets/' + name, path)
    return name
with ThreadPoolExecutor(max_workers=8) as pool:
    print('Assets ready:', len(list(pool.map(fetch, files))))
