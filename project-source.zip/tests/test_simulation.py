import unittest
import numpy as np
from scipy.spatial.transform import Rotation
from dual_arm.simulation import Simulation
from dual_arm.scene import MARKERS, TRACKER_POS, TRACKER_FRAME

class SimulationTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.sim=Simulation()

    def test_reachable_poses_and_limits(self):
        s=self.sim
        for kwargs in [{},{'x':.035,'y':.06,'tilt':10,'depth':.045},{'patient_x':-.03,'patient_y':.04,'patient_yaw':10},{'y':-.08,'depth':-.01}]:
            s.update(**kwargs)
            self.assertLess(max(s.errors.values()),.002,kwargs)
            for arm in ['probe','needle']:
                for i in range(7):
                    j=s.model.joint(f'{arm}_joint{i+1}')
                    q=s.data.qpos[j.qposadr[0]]
                    self.assertTrue(j.range[0]<=q<=j.range[1])

    def test_image_changes_with_pose_and_needle(self):
        s=self.sim; s.update(); base=s.ultrasound().astype(float)
        for kwargs in [{'y':.04},{'tilt':12},{'depth':.06}]:
            s.update(**kwargs)
            self.assertGreater(np.mean(np.abs(base-s.ultrasound())),.1,kwargs)

    def test_tracker_rigid_fit(self):
        s=self.sim; s.update()
        for arm in ['probe','needle']:
            track=s.tracking(arm,noise=0)
            self.assertTrue(track['valid'])
            self.assertLess(track['fit_rms_m'],1e-10)
            r=Rotation.from_quat(track['quaternion_xyzw']).as_matrix()
            estimated=MARKERS@r.T+track['position_m']
            actual=(np.array([s.pose(f'{arm}_marker{i}')[0] for i in range(4)])-TRACKER_POS)@TRACKER_FRAME
            np.testing.assert_allclose(estimated,actual,atol=1e-10)

if __name__=='__main__': unittest.main()
