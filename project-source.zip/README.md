# 双 Franka 超声引导穿刺演示

两条 Franka Panda 机械臂模拟双手操作：一臂固定超声探头，一臂固定穿刺针。人体模型可平移、旋转；探头位置和姿态决定合成超声切面；针在切面附近产生高亮回波。探头和针各安装四个非共面光学标记，外置相机提供人体与双臂画面。

## 运行

本目录的 `.venv` 已安装 CPU 演示依赖。Windows PowerShell：

```powershell
.\.venv\Scripts\python.exe -m dual_arm.app
```

或运行 `run.ps1`（优先使用已安装的 mjlab 场景后端）。滑块控制扫描横/纵位置、探头倾角、进针深度以及人体位姿。勾选“自动扫描 / 进针循环”可播放连续动作。保存按钮导出相机图、超声图和追踪 JSON 到 `outputs`。

```powershell
# 无交互窗口生成静态预览 / 动态 GIF
.\.venv\Scripts\python.exe -m dual_arm.app --snapshot
.\.venv\Scripts\python.exe -m dual_arm.app --record
# 10 秒 MP4：扫描、固定探头进针、退针；1280×720 / 20 fps
.\.venv-mjlab\Scripts\python.exe -m dual_arm.video --seconds 10 --fps 20
# 功能验证
.\.venv\Scripts\python.exe -m unittest discover -s tests -v
```

从空环境安装：Python 3.9+，创建 `.venv` 后安装 `requirements.txt`，运行 `python download_assets.py` 下载 Panda 网格。该下载只补齐缺失文件。

## mjlab 接入

`dual_arm/mjlab_scene.py` 用 `SceneCfg.spec_fn` 和 `MjSpec.attach` 将同一个 MJCF 场景加入 mjlab，保留相机和末端坐标名称。

```powershell
.\.venv-mjlab\Scripts\python.exe -m dual_arm.mjlab_scene
.\.venv-mjlab\Scripts\python.exe -m dual_arm.app --backend mjlab
```

mjlab 环境与 CPU 演示环境隔离，本机已安装 Python 3.11 / mjlab 1.6.0，并验证场景编译、截图和功能测试。复现时可在独立 Python 3.10+ 环境安装 `requirements-mjlab.txt`，不要与 CPU 环境的 MuJoCo 版本约束混装。当前接入的是 **mjlab 场景构建和编译**；交互演示仍由逆运动学设置关节位姿，再进行 MuJoCo 正运动学和相机渲染，尚非 mjlab GPU 动力学或强化学习环境。

## 坐标与数据

- 世界坐标单位为米；人体长轴为 Y，Z 朝上。人体的平移、旋转同步作用于内部合成组织。
- 探头 `probe_tip` 的局部 X 为图像横向，局部 Z 为声束深度；图像范围 130 × 140 mm。
- 光学追踪输出的是 `probe_tool` / `needle_tool` 在 `optical_tracker` 中的位姿，四元数顺序 XYZW。针尖与工具原点相距 0.19 m，探头成像原点与工具原点相距 0.062 m，均沿局部 Z。
- 标记位置添加 0.25 mm 标准差的模拟测量噪声，通过刚体最小二乘估计位姿；`valid`、`visible_markers`、`fit_rms_m` 一并输出。少于三个可见标记时不输出位姿。
- 外置相机 `external` 是真实 MuJoCo RGB 渲染；超声不是相机贴图，而是世界空间组织经探头坐标切片得到的合成灰度图。

## 实现范围

这是几何与成像联动原型。Panda 使用 Menagerie 真实网格与关节结构；人体为基本几何组合，包含程序化散射、组织层、血管和病灶。探头和针采用刚性工具连接，不模拟手指抓取过程。

合成超声包含空间固定散斑、深度衰减、组织边界和针回波，但没有声波传播、真实设备标定或病人影像。针允许几何进入人体，未模拟切割、软组织变形、接触力或针弯曲。运动没有碰撞规划，极端滑块组合可能不可达，应查看界面末端位置误差。

光学追踪目前模拟直接三维标记测量、距离和视场判定，不包含遮挡、反光球识别、双目三角化或真实追踪仪驱动。尚未接入真实机器人、超声设备或光学硬件。

## 文件

- `dual_arm/scene.py`：双臂、人体、工具、标记及相机。
- `dual_arm/simulation.py`：逆运动学、组织切片、针回波、标记位姿拟合。
- `dual_arm/app.py`：交互窗口、截图、动态演示。
- `tests/test_simulation.py`：代表性位姿、成像变化和追踪坐标验证。

Panda 模型来自 [Google DeepMind MuJoCo Menagerie](https://github.com/google-deepmind/mujoco_menagerie/tree/main/franka_emika_panda)，许可证保存在 `assets/LICENSE.franka`。场景组合接口依据 [mjlab Scene 文档](https://mujocolab.github.io/mjlab/main/source/scene.html)。
