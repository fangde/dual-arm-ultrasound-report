import argparse
import json
import math
from pathlib import Path
import tkinter as tk
from tkinter import ttk
import mujoco
from PIL import Image, ImageTk, ImageDraw
from .simulation import Simulation

OUT = Path(__file__).resolve().parents[1] / 'outputs'

def panel(sim, renderer):
    renderer.update_scene(sim.data, camera='external')
    external=Image.fromarray(renderer.render())
    us=Image.fromarray(sim.ultrasound()).convert('RGB')
    draw=ImageDraw.Draw(us)
    draw.text((10,8),'SYNTHETIC B-MODE | 130 x 140 mm',fill='#55dddf')
    for mm in range(20,141,20):
        row=int(mm/140*319)
        draw.line((340,row,359,row),fill='white')
        draw.text((310,max(0,row-13)),str(mm),fill='white')
    return external,us

def snapshot(sim, renderer):
    OUT.mkdir(exist_ok=True)
    external,us=panel(sim,renderer)
    external.save(OUT/'external.png'); us.save(OUT/'ultrasound.png')
    joined=Image.new('RGB',(external.width+us.width,external.height),'#111b25')
    joined.paste(external,(0,0)); joined.paste(us,(external.width,40))
    ImageDraw.Draw(joined).text((external.width+12,380),'Pose-driven demo / synthetic tissue',fill='white')
    joined.save(OUT/'preview.png')
    record={'time_s':sim.data.time,'ik_position_error_m':sim.errors,'probe':sim.tracking('probe'),'needle':sim.tracking('needle')}
    (OUT/'tracking.json').write_text(json.dumps(record,indent=2),encoding='utf-8')
    print(OUT/'preview.png')

def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--snapshot',action='store_true')
    parser.add_argument('--record',action='store_true',help='Save a short animated demonstration')
    parser.add_argument('--backend',choices=['mujoco','mjlab'],default='mujoco')
    args=parser.parse_args()
    model=None
    if args.backend=='mjlab':
        from .mjlab_scene import compile_scene
        model=compile_scene()
    sim=Simulation(model); sim.update()
    renderer=mujoco.Renderer(sim.model,height=540,width=720)
    if args.record:
        OUT.mkdir(exist_ok=True)
        frames=[]
        try:
            for i in range(40):
                phase=2*math.pi*i/40
                sim.update(y=.045*math.sin(phase),depth=.022+.035*math.sin(phase))
                a,b=panel(sim,renderer)
                canvas=Image.new('RGB',(1080,540),'#111b25')
                canvas.paste(a,(0,0)); canvas.paste(b,(720,40))
                frames.append(canvas.resize((900,450)))
            frames[0].save(OUT/'demo.gif',save_all=True,append_images=frames[1:],duration=100,loop=0)
        finally: renderer.close()
        print(OUT/'demo.gif')
        return
    if args.snapshot:
        try: snapshot(sim,renderer)
        finally: renderer.close()
        return
    root=tk.Tk(); root.title('双 Franka · 超声引导穿刺仿真'); root.configure(bg='#111b25')
    views=tk.Frame(root,bg='#111b25'); views.pack()
    left=tk.Label(views,bg='#111b25'); left.grid(row=0,column=0)
    right=tk.Label(views,bg='#111b25'); right.grid(row=0,column=1,sticky='n',pady=30)
    controls=ttk.Frame(root,padding=10); controls.pack(fill='x')
    variables={}
    specs=[('x','扫描横向 mm',-55,55,0,.001),('y','扫描纵向 mm',-110,110,0,.001),('tilt','探头倾角 °',-20,20,0,1),('depth','进针深度 mm',-20,65,20,.001),('patient_x','人体横移 mm',-50,50,0,.001),('patient_y','人体纵移 mm',-60,60,0,.001),('patient_yaw','人体旋转 °',-15,15,0,1)]
    for i,(name,label,low,high,value,scale) in enumerate(specs):
        frame=ttk.Frame(controls); frame.grid(row=i//4,column=i%4,padx=8)
        var=tk.DoubleVar(value=value); variables[name]=(var,scale)
        tk.Scale(frame,from_=low,to=high,resolution=1,orient='horizontal',length=235,label=label,variable=var).pack()
    animate=tk.BooleanVar(value=False)
    ttk.Checkbutton(controls,text='自动扫描 / 进针循环',variable=animate).grid(row=1,column=3)
    status=tk.StringVar()
    ttk.Label(root,textvariable=status,padding=8).pack(fill='x')
    ttk.Button(root,text='保存相机、超声和追踪数据',command=lambda:snapshot(sim,renderer)).pack(pady=5)
    running=True; phase=0
    def tick():
        nonlocal phase
        if not running: return
        phase+=.045
        if animate.get():
            variables['y'][0].set(65*math.sin(phase*.45))
            variables['depth'][0].set(20+35*math.sin(phase))
        sim.update(**{name:var.get()*scale for name,(var,scale) in variables.items()})
        a,b=panel(sim,renderer)
        left.image=ImageTk.PhotoImage(a); left.configure(image=left.image)
        right.image=ImageTk.PhotoImage(b); right.configure(image=right.image)
        tracking=[sim.tracking(name) for name in ['probe','needle']]
        status.set('光学标记可见：探头 %d/4，针 %d/4  |  末端位置误差：%.1f / %.1f mm  |  合成超声；几何穿刺；追踪未建模遮挡' % (tracking[0]['visible_markers'],tracking[1]['visible_markers'],1000*sim.errors['probe'],1000*sim.errors['needle']))
        root.after(50,tick)
    def close():
        nonlocal running
        running=False; renderer.close(); root.destroy()
    root.protocol('WM_DELETE_WINDOW',close)
    tick(); root.mainloop()

if __name__=='__main__': main()
