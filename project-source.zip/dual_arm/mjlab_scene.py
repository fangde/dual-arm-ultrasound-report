"""Compose the exact demonstration MJCF through mjlab SceneCfg.

The raw-scene hook preserves camera/site names for the image and tracker modules.
This is a scene integration, not an RL environment or a tissue dynamics model.
"""
import mujoco
from .scene import scene_xml

def make_scene_cfg(num_envs=1):
    from mjlab.scene import SceneCfg
    def attach(spec):
        source=mujoco.MjSpec.from_string(scene_xml())
        spec.option.integrator=source.option.integrator
        spec.option.timestep=source.option.timestep
        spec.attach(source,prefix='',frame=spec.worldbody.add_frame())
        spec.visual.global_.offwidth=960
        spec.visual.global_.offheight=720
    return SceneCfg(num_envs=num_envs,env_spacing=3.,spec_fn=attach)

def compile_scene():
    from mjlab.scene import Scene
    return Scene(make_scene_cfg(),device='cpu').compile()

if __name__=='__main__':
    m=compile_scene()
    print(f'mjlab scene compiled: {m.nq} positions, {m.nu} actuators, {m.ncam} camera')
