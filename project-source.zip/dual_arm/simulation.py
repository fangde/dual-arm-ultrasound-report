"""Pose-driven coordinated demonstration; no tissue mechanics are inferred."""
import numpy as np
import mujoco
from scipy.spatial.transform import Rotation
from scipy.ndimage import gaussian_filter, map_coordinates
from .scene import load, MARKERS, TRACKER_POS, TRACKER_FRAME

class Simulation:
    def __init__(self, model=None):
        self.model = load() if model is None else model
        self.data = mujoco.MjData(self.model)
        self.rng = np.random.default_rng(42)
        self.patient_pos = np.array([0.,0.,.68])
        self.patient_rot = np.eye(3)
        self.errors = {}
        noise = np.random.default_rng(123).normal(size=(128,256,128)).astype(np.float32)
        self.scatter = gaussian_filter(noise, .65)
        self.scatter /= self.scatter.std()
        for arm in ['probe','needle']:
            for i, q in enumerate([0,-.35,0,-1.8,0,1.5,.785]):
                self.data.qpos[self.model.joint(f'{arm}_joint{i+1}').qposadr[0]] = q
        mujoco.mj_forward(self.model, self.data)

    def pose(self, name, kind='site'):
        obj = getattr(self.data, kind)(name)
        return obj.xpos.copy(), obj.xmat.reshape(3,3).copy()

    def ik(self, arm, target, rotation):
        ids = [self.model.joint(f'{arm}_joint{i+1}').id for i in range(7)]
        qa = self.model.jnt_qposadr[ids]
        da = self.model.jnt_dofadr[ids]
        bounds = self.model.jnt_range[ids]
        sid = self.model.site(arm+'_tip').id
        jp, jr = np.zeros((3,self.model.nv)), np.zeros((3,self.model.nv))
        for _ in range(100):
            mujoco.mj_forward(self.model,self.data)
            pos, rot = self.pose(arm+'_tip')
            ep = target-pos
            er = Rotation.from_matrix(rotation @ rot.T).as_rotvec()
            if np.linalg.norm(ep)<.0004 and np.linalg.norm(er)<.004:
                break
            mujoco.mj_jacSite(self.model,self.data,jp,jr,sid)
            j = np.vstack([jp[:,da], .25*jr[:,da]])
            e = np.r_[ep, .25*er]
            dq = j.T @ np.linalg.solve(j@j.T+.0001*np.eye(6),e)
            self.data.qpos[qa] = np.clip(self.data.qpos[qa]+np.clip(dq,-.12,.12), bounds[:,0]+.001,bounds[:,1]-.001)
        mujoco.mj_forward(self.model,self.data)
        self.errors[arm] = float(np.linalg.norm(target-self.pose(arm+'_tip')[0]))

    def update(self, x=0., y=0., tilt=0., depth=.02, patient_x=0., patient_y=0., patient_yaw=0.):
        self.patient_pos = np.array([patient_x,patient_y,.68])
        self.patient_rot = Rotation.from_euler('z',patient_yaw,degrees=True).as_matrix()
        self.data.mocap_pos[0] = self.patient_pos
        q = Rotation.from_matrix(self.patient_rot).as_quat()
        self.data.mocap_quat[0] = q[[3,0,1,2]]
        z = .13*np.sqrt(max(.05,1-(x/.19)**2-(y/.34)**2))
        origin = self.patient_pos+self.patient_rot@np.array([x,y,z+.002])
        rot = self.patient_rot @ Rotation.from_euler('y',tilt,degrees=True).as_matrix() @ np.diag([1.,-1.,-1.])
        self.ik('probe',origin,rot)
        # Needle lies in the probe's x-z imaging plane, 35 degrees to its normal.
        nr = rot @ Rotation.from_euler('y',-35,degrees=True).as_matrix()
        entry = origin + rot@np.array([.037,0,0])
        tip = entry + nr[:,2]*depth
        self.ik('needle',tip,nr)
        self.data.time += 1/20

    def ultrasound(self, width=360, height=320):
        p, r = self.pose('probe_tip')
        xx, zz = np.meshgrid(np.linspace(-.065,.065,width),np.linspace(0,.14,height))
        world = p + xx[...,None]*r[:,0] + zz[...,None]*r[:,2]
        v = (world-self.patient_pos) @ self.patient_rot
        x,y,z = v[...,0],v[...,1],v[...,2]
        inside = (x/.19)**2+(y/.34)**2+(z/.13)**2 < 1
        surface = .13*np.sqrt(np.maximum(0,1-(x/.19)**2-(y/.34)**2))
        d = surface-z
        # Stationary 3D procedural scatterers: the image changes with the slice.
        coords = np.array([(x+.24)/.48*127,(y+.85)/1.45*255,(z+.15)/.3*127])
        speckle = map_coordinates(self.scatter,coords,order=1,mode='nearest')
        intensity = 48+23*speckle + 70*np.exp(-((d-.002)/.0015)**2)+32*np.exp(-((d-.025)/.002)**2)
        lesion = np.sqrt(((x-.005)/.018)**2+(y/.027)**2+((z-.07)/.014)**2)
        intensity -= 27*np.exp(-lesion**4)
        intensity += 28*np.exp(-((lesion-1)/.10)**2)
        vessel = np.sqrt((x+.045+.012*np.sin(18*y))**2+(z-.075)**2)
        intensity = np.where(vessel<.007,8,intensity)
        intensity += 35*np.exp(-((vessel-.008)/.001)**2)
        a,_ = self.pose('needle_base')
        b,_ = self.pose('needle_tip')
        ab=b-a
        t=np.clip(np.sum((world-a)*ab,axis=-1)/np.dot(ab,ab),0,1)
        dist=np.linalg.norm(world-(a+t[...,None]*ab),axis=-1)
        intensity += 180*np.exp(-(dist/.0015)**2)
        intensity *= np.exp(-4*zz)
        intensity = np.where(inside,intensity,0)
        # Air gap suppresses signal; pose remains the source of the section.
        local=(p-self.patient_pos)@self.patient_rot
        contact=abs(local[2]-.13*np.sqrt(max(0,1-(local[0]/.19)**2-(local[1]/.34)**2)))<.008
        if not contact:
            intensity *= .08
        return np.uint8(np.clip(intensity,0,255))

    def tracking(self, arm, noise=.00025):
        """Noisy 3D markers in a tracker frame, then rigid least-squares fit.

        Visibility is range/FOV only; no stereo triangulation or occlusion model.
        """
        origin=TRACKER_POS
        frame=TRACKER_FRAME
        points=np.array([self.pose(f'{arm}_marker{i}')[0] for i in range(4)])
        measured=(points-origin)@frame
        valid=(measured[:,2]>.2)&(measured[:,2]<3)&(np.abs(measured[:,0])<measured[:,2]*.8)&(np.abs(measured[:,1])<measured[:,2]*.65)
        result={'valid':bool(valid.sum()>=3),'visible_markers':int(valid.sum()),'frame':'optical_tracker','noise_std_m':noise}
        if not result['valid']:
            return result
        measured+=self.rng.normal(0,noise,measured.shape)
        a=MARKERS[valid]; b=measured[valid]
        ac=a-a.mean(0); bc=b-b.mean(0)
        u,_,vt=np.linalg.svd(ac.T@bc)
        fix=np.eye(3); fix[-1,-1]=np.linalg.det(vt.T@u.T)
        rot=vt.T@fix@u.T; pos=b.mean(0)-rot@a.mean(0)
        result.update(position_m=pos.tolist(),quaternion_xyzw=Rotation.from_matrix(rot).as_quat().tolist(),fit_rms_m=float(np.sqrt(np.mean(np.sum((a@rot.T+pos-b)**2,axis=1)))))
        return result
