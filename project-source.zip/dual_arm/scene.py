from pathlib import Path
from copy import deepcopy
import xml.etree.ElementTree as E
import numpy as np
import mujoco

ROOT = Path(__file__).resolve().parents[1]
MARKERS = np.array([[-.055, -.04, -.02], [.06, -.035, -.015], [.035, .055, -.04], [-.035, .025, -.075]])
TRACKER_POS = np.array([0., -.9, 1.6])
_forward = np.array([0., .9, -.8]); _forward /= np.linalg.norm(_forward)
TRACKER_FRAME = np.column_stack(([1., 0., 0.], np.cross(_forward, [1., 0., 0.]), _forward))

def add(parent, tag, **attrs):
    return E.SubElement(parent, tag, {k: str(v) for k, v in attrs.items()})

def scene_xml():
    source = E.parse(ROOT / 'assets/panda.xml').getroot()
    root = E.Element('mujoco', model='dual_franka_ultrasound')
    add(root, 'compiler', angle='radian', meshdir=(ROOT / 'assets/assets').as_posix(), autolimits='true')
    add(root, 'option', timestep='.002', integrator='implicitfast')
    visual = add(root, 'visual')
    add(visual, 'global', offwidth='960', offheight='720')
    root.append(deepcopy(source.find('default')))
    root.append(deepcopy(source.find('asset')))
    world = add(root, 'worldbody')
    add(world, 'light', pos='0 -1 3', dir='0 0 -1', diffuse='.8 .8 .8', castshadow='false')
    add(world, 'light', pos='1 1 2', dir='-1 -1 -1', diffuse='.5 .5 .5', castshadow='false')
    add(world, 'geom', name='floor', type='plane', size='3 3 .1', rgba='.12 .16 .21 1')
    add(world, 'geom', name='table', type='box', pos='0 0 .48', size='.38 .9 .04', rgba='.25 .32 .37 1')
    for x in [-.55, .55]:
        add(world, 'geom', type='box', pos=f'{x} -.05 .26', size='.13 .13 .26', rgba='.32 .38 .44 1')
    for y in [-.65, .65]:
        add(world, 'geom', type='box', pos=f'0 {y} .22', size='.22 .05 .22', rgba='.25 .32 .37 1')
    patient = add(world, 'body', name='patient', mocap='true', pos='0 0 .68')
    skin = '.72 .48 .36 1'
    add(patient, 'geom', name='torso', type='ellipsoid', size='.19 .34 .13', rgba=skin)
    add(patient, 'geom', name='head', type='ellipsoid', pos='0 .45 0', size='.095 .12 .11', rgba=skin)
    for x in [-.12, .12]:
        add(patient, 'geom', type='capsule', fromto=f'{x} -.25 -.04 {x} -.75 -.06', size='.068', rgba=skin)
    for x in [-.25, .25]:
        add(patient, 'geom', type='capsule', fromto=f'{x} .23 -.03 {x} -.27 -.06', size='.045', rgba=skin)
    target = add(patient, 'site', name='target', pos='0 0 .07', size='.009', rgba='1 .25 .25 .4', group='4')
    add(world, 'camera', name='external', pos='1.6 -2.1 2', xyaxes='.795 .606 0 -.29 .38 .878', fovy='48')
    tracker = add(world, 'body', name='tracker', pos=' '.join(map(str,TRACKER_POS)))
    add(tracker, 'geom', type='box', size='.27 .045 .055', rgba='.15 .2 .25 1')
    for x in [-.22, .22]:
        add(tracker, 'geom', type='sphere', pos=f'{x} -.045 -.035', size='.025', rgba='.1 .8 .9 1')
    for prefix, base, quat in [('probe', '-.55 -.05 .52', '1 0 0 0'), ('needle', '.55 -.05 .52', '0 0 0 1')]:
        robot = deepcopy(source.find("worldbody/body"))
        names = {e.get('name') for e in robot.iter() if e.get('name')}
        names.update(e.get('name') for section in ['tendon','actuator'] for e in source.find(section).iter() if e.get('name'))
        def rename(tree):
            for e in tree.iter():
                for key in ['name', 'joint', 'joint1', 'joint2', 'body1', 'body2', 'tendon']:
                    if e.get(key) in names:
                        e.set(key, prefix + '_' + e.get(key))
            return tree
        rename(robot)
        robot.set('pos', base)
        robot.set('quat', quat)
        world.append(robot)
        hand = robot.find(f".//body[@name='{prefix}_hand']")
        tool = add(hand, 'body', name=prefix+'_tool', pos='0 0 .105')
        if prefix == 'probe':
            add(tool, 'geom', type='box', pos='0 0 .025', size='.022 .013 .025', rgba='.25 .7 .9 1')
            add(tool, 'geom', type='box', pos='0 0 .055', size='.027 .009 .007', rgba='.08 .1 .13 1')
            add(tool, 'site', name='probe_tip', pos='0 0 .062', size='.003', rgba='0 1 1 1')
        else:
            add(tool, 'geom', type='cylinder', size='.009 .025', rgba='.95 .6 .1 1')
            add(tool, 'geom', name='needle_shaft', type='capsule', fromto='0 0 .025 0 0 .19', size='.0012', rgba='.8 .85 .9 1', contype='0', conaffinity='0')
            add(tool, 'site', name='needle_tip', pos='0 0 .19', size='.002', rgba='1 .3 .1 1')
            add(tool, 'site', name='needle_base', pos='0 0 .025', size='.002')
        for i, p in enumerate(MARKERS):
            xyz = ' '.join(map(str,p))
            add(tool, 'geom', type='capsule', fromto='0 0 0 '+xyz, size='.0025', rgba='.25 .28 .3 1', contype='0', conaffinity='0')
            add(tool, 'geom', type='sphere', pos=xyz, size='.006', rgba='.9 1 .5 1', contype='0', conaffinity='0')
            add(tool, 'site', name=f'{prefix}_marker{i}', pos=xyz, size='.001')
        for section in ['tendon','equality','actuator','contact']:
            out = root.find(section)
            if out is None:
                out = add(root, section)
            for element in source.find(section):
                out.append(rename(deepcopy(element)))
    return E.tostring(root, encoding='unicode')

def load():
    return mujoco.MjModel.from_xml_string(scene_xml())

if __name__ == '__main__':
    path = ROOT / 'outputs/scene.xml'
    path.parent.mkdir(exist_ok=True)
    path.write_text(scene_xml(), encoding='utf-8')
    print(path)
