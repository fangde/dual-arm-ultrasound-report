"""Render a timed dual-arm demonstration as an H.264 MP4."""
import argparse
import json
from pathlib import Path

import imageio_ffmpeg
import mujoco
import numpy as np
from PIL import Image, ImageDraw, ImageFont

from .app import panel, OUT
from .simulation import Simulation


def smooth(value):
    value = np.clip(value, 0, 1)
    return float(value * value * (3 - 2 * value))


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--seconds', type=float, default=10)
    parser.add_argument('--fps', type=int, default=20)
    args = parser.parse_args()
    if args.seconds <= 0 or args.fps <= 0:
        parser.error('seconds and fps must be positive')
    from .mjlab_scene import compile_scene
    sim = Simulation(compile_scene())
    renderer = mujoco.Renderer(sim.model, height=660, width=880)
    OUT.mkdir(exist_ok=True)
    output = OUT / f'dual_franka_{args.seconds:g}s.mp4'
    font_path = Path('C:/Windows/Fonts/msyh.ttc')
    font = ImageFont.truetype(str(font_path), 22)
    small = ImageFont.truetype(str(font_path), 16)
    title = ImageFont.truetype(str(font_path), 28)
    count = round(args.seconds * args.fps)
    writer = imageio_ffmpeg.write_frames(
        str(output), (1280, 720), fps=args.fps, codec='libx264',
        pix_fmt_out='yuv420p', quality=8, macro_block_size=1,
        output_params=['-movflags', '+faststart'],
    )
    writer.send(None)
    samples = []
    try:
        for i in range(count):
            t = i / args.fps
            phase = i / max(1, count - 1)
            if phase < .4:
                u = smooth(phase / .4)
                y = -.065 * (1 - u)
                depth = -.012
                label = '扫描定位'
            elif phase < .72:
                y = 0
                depth = -.012 + .077 * smooth((phase - .4) / .32)
                label = '保持探头 · 进针'
            else:
                y = 0
                depth = .065 - .077 * smooth((phase - .72) / .28)
                label = '保持探头 · 退针'
            sim.update(y=y, depth=depth)
            sim.data.time = t
            camera, ultrasound = panel(sim, renderer)
            frame = Image.new('RGB', (1280, 720), '#101b27')
            frame.paste(camera, (0, 60))
            frame.paste(ultrasound.resize((380, 338)), (890, 113))
            draw = ImageDraw.Draw(frame)
            draw.text((24, 13), '双 Franka 超声引导穿刺', font=title, fill='white')
            draw.text((890, 22), f'{t:04.1f} / {args.seconds:g} 秒', font=font, fill='#68dde2')
            draw.text((900, 74), '合成超声 · 实时切面', font=font, fill='white')
            draw.text((900, 470), label, font=font, fill='#68dde2')
            draw.text((900, 510), f'扫描位置  {y * 1000:+.1f} mm', font=small, fill='white')
            draw.text((900, 538), f'进针位移  {depth * 1000:+.1f} mm', font=small, fill='white')
            tracks = {arm: sim.tracking(arm) for arm in ['probe', 'needle']}
            draw.text((900, 581), '光学追踪（模拟）', font=small, fill='#68dde2')
            draw.text((900, 610), '探头 %d/4 标记  |  针 %d/4 标记' % (
                tracks['probe']['visible_markers'], tracks['needle']['visible_markers']), font=small, fill='white')
            draw.text((900, 672), '几何演示 · 未模拟软组织动力学', font=small, fill='#a3b4c5')
            draw.rectangle((0, 715, int(1280 * (i + 1) / count), 719), fill='#68dde2')
            writer.send(np.asarray(frame))
            samples.append({'time_s': t, 'phase': label, 'scan_y_m': y,
                            'needle_displacement_m': depth,
                            'ik_error_m': dict(sim.errors), 'tracking': tracks})
            if i in [0, count // 2, count - 1]:
                frame.save(OUT / f'video_frame_{i:04d}.png')
            if i % args.fps == 0:
                print(f'Rendered {i}/{count}', flush=True)
    finally:
        writer.close()
        renderer.close()
    (OUT / 'video_telemetry.json').write_text(json.dumps(samples, ensure_ascii=False, indent=2), encoding='utf-8')
    print(output, flush=True)


if __name__ == '__main__':
    main()
