"""Dual Franka ultrasound and needle research demonstration."""
