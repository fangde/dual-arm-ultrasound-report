$ErrorActionPreference = 'Stop'
Set-Location $PSScriptRoot
if (Test-Path "$PSScriptRoot\.venv-mjlab\Scripts\python.exe") {
    & "$PSScriptRoot\.venv-mjlab\Scripts\python.exe" -m dual_arm.app --backend mjlab
} else {
    & "$PSScriptRoot\.venv\Scripts\python.exe" -m dual_arm.app
}
